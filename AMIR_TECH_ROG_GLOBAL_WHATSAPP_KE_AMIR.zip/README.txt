Versi WhatsApp kepada Amir
1. Backup index.html lama.
2. Gantikan index.html di folder utama GitHub dengan fail dalam ZIP.
3. Commit perubahan.
4. Buka website dan refresh/cache clear.
Butang menggunakan navigasi terus ke WhatsApp dengan laporan untuk Amir di nombor 60133133519.
Pengguna masih perlu menekan Hantar dalam aplikasi WhatsApp.
